# The frontend normally reaches the API through the Vite proxy (same origin),
# so CORS only matters when the API is called directly from another origin.
Rails.application.config.middleware.insert_before 0, Rack::Cors do
  allow do
    origins ENV.fetch("CORS_ORIGINS", "*").split(",").map(&:strip)
    resource "/api/*", headers: :any, methods: %i[get post put patch delete options head]
  end
end
