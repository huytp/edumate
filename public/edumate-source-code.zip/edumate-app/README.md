# EduMate – Người Bạn Đồng Hành Của Giáo Viên (Lớp 1 Tiểu Học)

Ứng dụng quản lý lớp học toàn diện, tạo trò chơi tương tác có giọng đọc cô giáo chuẩn mực, đánh giá học sinh chuẩn theo **Thông tư 27/2020/TT-BGDĐT** và kết nối 2 chiều giữa giáo viên và phụ huynh học sinh.

---

## 🌟 Tính Năng Nổi Bật

1. **Hiển thị tối ưu mọi thiết bị (Điện thoại & Máy tính)**:
   - Tự động co giãn theo kích thước màn hình điện thoại (Responsive chuẩn).
   - Thanh điều hướng nhanh phía dưới màn hình điện thoại (Mobile Bottom Navigation).
   - Menu trượt (Mobile Drawer) mượt mà, tiện lợi.
2. **Âm thanh & Giọng đọc cô giáo dịu dàng 100%**:
   - Thay thế toàn bộ giọng đọc nam nhanh bằng giọng nữ trợ giảng ngọt ngào, ấm áp.
   - Tốc độ đọc chậm rãi (0.70x), rõ ràng, phù hợp tuyệt đối cho học sinh lớp 1.
   - Phát âm tiếng Việt và Tiếng Anh chuẩn (Good job, Well done, Wonderful, Keep going, Don't worry, Nice try).
3. **Âm nhạc vui nhộn trên bảng điều khiển**:
   - Kho bài hát khởi động thể dục, tiếng Anh, đồng dao thiếu nhi và nhạc thư giãn.
   - Trình phát video YouTube / nhạc trực tiếp cho học sinh nghe và xem.
   - Cho phép giáo viên dán thêm link video hoặc xóa bài hát tùy ý.
4. **Trò chơi tương tác đa dạng**:
   - Trò chơi trắc nghiệm tiếng Anh, toán học, câu đố lớp 1.
   - Cô giáo đọc chậm từng câu hỏi và 4 đáp án giúp các em chưa biết đọc chữ vẫn tham gia được.
   - Vòng quay gọi tên ngẫu nhiên kết hợp hộp quà bí mật và lật thẻ bài.
   - Chức năng quản lý: Thêm câu hỏi mới, sửa, hoặc xóa trò chơi không cần thiết.
5. **Đánh giá theo Thông tư 27/2020/TT-BGDĐT**:
   - Ngân hàng mẫu nhận xét môn học, năng lực, phẩm chất chuẩn mực sư phạm.
   - 1-Click copy lời phê để dán vào hệ thống SMAS / VnEdu.
   - Bảng tổng hợp cuối kỳ, xuất file Word và Excel chính xác theo biểu mẫu quy định.
6. **Kết nối phụ huynh học sinh**:
   - Cổng tra cứu riêng cho từng phụ huynh bằng mã học sinh hoặc mã QR.
   - Nhận phản hồi, tin nhắn từ phụ huynh tức thì.

---

## 🚀 Hướng Dẫn Cài Đặt & Chạy Ứng Dụng Trên Máy Tính

### Yêu Cầu Hệ Thống:
- Đã cài đặt **Node.js** (Khuyến nghị phiên bản 18 hoặc 20 trở lên). Tải tại: [https://nodejs.org](https://nodejs.org)

### Các Bước Thực Hiện:

```bash
# 1. Giải nén file ZIP vừa tải về:
# Bạn nhấp chuột phải vào file edumate-source-code.zip -> chọn Extract All (Giải nén)

# 2. Mở cửa sổ dòng lệnh (Terminal / Command Prompt / PowerShell) tại thư mục vừa giải nén:

# 3. Cài đặt các thư viện phụ thuộc:
npm install

# 4. Khởi động ứng dụng ở chế độ phát triển:
npm run dev

# 5. Mở trình duyệt web (Chrome, Edge, Cốc Cốc, Safari) và truy cập địa chỉ:
# http://localhost:3000
```

---

## 📱 Sử Dụng Trên Điện Thoại (Thêm vào Màn hình chính như App)

1. Mở link ứng dụng trên trình duyệt điện thoại (Safari trên iPhone hoặc Chrome trên Android).
2. Nhấn nút **Chia sẻ** (Safari) hoặc biểu tượng **3 chấm** (Chrome).
3. Chọn **"Thêm vào Màn hình chính" (Add to Home Screen)**.
4. Biểu tượng EduMate 🎒 sẽ xuất hiện trên màn hình điện thoại, bạn có thể mở lên xem toàn màn hình đúng chuẩn ứng dụng native!
